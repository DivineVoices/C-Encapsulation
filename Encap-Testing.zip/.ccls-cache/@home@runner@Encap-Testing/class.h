#ifndef TESTING_H__
#define TESTING_H__
#include <string>

class Point {
public:
  float x, y, z;
  std::string ToString();
};
#endif