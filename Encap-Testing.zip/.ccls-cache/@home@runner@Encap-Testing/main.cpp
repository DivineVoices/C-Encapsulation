#include "class.h"
#include <iostream>
#include <string>

int main(int argc, const char *argv[]) {
  Point Random;

  std::cout << "Enter x : ";
  std::cin >> Random.x;
  std::cout << "Enter y : ";
  std::cin >> Random.y;
  std::cout << "Enter z : ";
  std::cin >> Random.z;

  std::cout << Random.ToString() << std::endl;
}