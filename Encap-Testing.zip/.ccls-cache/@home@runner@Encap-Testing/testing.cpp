#include "testing.h"
#include <sstream>

std::string Point::ToString() {
  std::stringstream ss;
  ss << "x: " << x << ", y: " << y << ", z: " << z;
  return ss.str();
}
